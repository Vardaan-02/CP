#include <bits/stdc++.h>

using namespace std;

const int M = 1000000007;
const int N = 1e5+10;

void precalc(){}

int n,m;

class Ques1{
    void dfs(int i,int j,vector<vector<int>>& visited,vector<string>& v){
        visited[i][j] = 1;
        vector<int> a = {0,1,0,-1,0};
        for(int k=0 ; k<4 ; k++){
            int x = i+a[k];
            int y = j+a[k+1];
            if(x>=0 && x<n && y>=0 && y<m && v[x][y]=='.' && !visited[x][y]){
                dfs(x,y,visited,v);
            }
        }
    }

    void solve(){
        cin >> n >> m;
        vector<string> v(n);
        for(int i=0 ; i<n ; i++) cin >> v[i];
        vector<vector<int>> visited(n,vector<int>(m,0));
        int count = 0;
        for(int i=0 ; i<n ; i++){
            for(int j=0 ; j<m ; j++){
                if(v[i][j]=='.' && !visited[i][j]){
                    dfs(i,j,visited,v);
                    count++;
                }
            }
        }
        cout << count << endl;
    }
};

class Ques2{
    bool bfs(pair<int,int> src,vector<string>& v,pair<int,int> des,string& ans){
        vector<vector<char>> visited(n,vector<char>(m,'.'));
        queue<pair<int,int>> q;
        q.push(src);
        visited[src.first][src.second] = true;
        vector<int> d = {0,1,0,-1,0};
        while(!q.empty()){
            int a = q.front().first;
            int b = q.front().second;
            q.pop();
            if(a==des.first && b==des.second){
                while(v[a][b]!='A'){
                    ans.push_back(visited[a][b]);
                    if(visited[a][b]=='U') a++;
                    else if(visited[a][b]=='D') a--;
                    else if(visited[a][b]=='R') b--;
                    else b++;
                }
                reverse(ans.begin(),ans.end());
                return true; 
            }
            for(int i=0 ; i<4 ; i++){
                int x = a+d[i];
                int y = b+d[i+1];
                if(x>=0 && x<n && y>=0 && y<m && v[x][y]!='#' && visited[x][y]=='.'){
                    if(i==0) visited[x][y] = 'R';
                    else if(i==1) visited[x][y] = 'D';
                    else if(i==2) visited[x][y] = 'L';
                    else visited[x][y] = 'U';
                    q.push({x,y});
                }
            }
        }
        return false;
    }

    void solve(){
        cin >> n >> m;
        pair<int,int> src,des;
        vector<string> v(n);
        for(int i=0 ; i<n ; i++) cin >> v[i];
        for(int i=0 ; i<n ; i++) for(int j=0 ; j<m ; j++) if(v[i][j]=='A') src = {i,j}; else if(v[i][j]=='B') des = {i,j};
        string ans;
        if(bfs(src,v,des,ans)){
            cout << "YES" << endl;
            cout << ans.size() << endl;
            cout << ans << endl;
        }
        else{
            cout << "NO" << endl;
        }
    }
};

class Ques5{
    int n,k;

    bool bfs(int src,map<int,vector<int>>& adjList,vector<int>& ans,vector<bool>& visited){
        queue<int> q;
        q.push(src);
        visited[src] = true;
        bool color = true;
        while(!q.empty()){
            int len = q.size();
            while(len--){
                int front = q.front();
                ans[front] = (color) ? 1 : 2;
                q.pop();
                for(auto i:adjList[front]){
                    if(!visited[i]){
                        q.push(i);
                        visited[i] = true;
                    }
                    else{
                        if(ans[i]==2 && !color) return false;
                        else if(ans[i]==1 && color) return false;
                    }
                }
            }
            color = !color;
        }

        return true;
    }

    void solve(){
        cin >> n >> k;
        map<int,vector<int>> adjList;
        for(int i=0 ; i<k ; i++){
            int a,b;
            cin >> a >> b;
            a--;b--;
            adjList[a].push_back(b);
            adjList[b].push_back(a);
        }
        vector<int> ans(n,0);
        vector<bool> visited(n,false);
        for(int i=0 ; i<n ; i++){
            if(!visited[i] && !bfs(i,adjList,ans,visited)){
                cout << "IMPOSSIBLE" << endl;
                return;
            }
        }
        for(int i=0 ; i<n ; i++) cout << ans[i] << " ";cout << endl;
    }
};

int32_t main(){
    ios_base::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    // precalc();
    // int t;
    // cin >> t;
    // while(t--){
    //     solve();
    // }
    return 0;
}